# Project Zomboid - Mod - No Picking-Up Please!
A mod for the game Project Zomboid to remove the possibility to pickup containers.
